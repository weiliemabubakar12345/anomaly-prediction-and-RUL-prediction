import pandas as pd
import sys
import os
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression, Ridge
import numpy as np
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.layers import Input, LSTM, Dense, Dropout, RepeatVector, TimeDistributed, Conv1D, MaxPooling1D, UpSampling1D, Flatten, Reshape
from tensorflow.keras.optimizers import Adam
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix, accuracy_score, classification_report
import seaborn as sns
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.losses import BinaryCrossentropy
from tensorflow.keras.metrics import BinaryAccuracy
from tensorflow.keras import backend as K
from tensorflow.keras.layers import Lambda
import tensorflow as tf

# Define the column names
column_names = ['unit_number', 'time_in_cycles', 'setting_1', 'setting_2', 'setting_3',
                'T2[°R]', 'T24[°R]', 'T30[°R]', 'T50[°R]',
                'P2[psia]', 'P15[psia]', 'P30[psia]',
                'Nf[rpm]', 'Nc[rpm]', 'epr[--]',
                'Ps30[psia]', 'phi[pps/psi]', 'NRf[rpm]',
                'NRc[rpm]', 'BPR[--]', 'farB[--]',
                'htBleed[--]', 'Nf_dmd[rpm]',
                'PCNfR_dmd[rpm]', 'W31[lbm/s]', 'W32[lbm/s]']

# Define the base directory where your dataset is stored
base_directory = r'D:\MITLAB-Abu\Preventive Maintenance\1. Dataset'
# base_directory = '/Users/weiliemabubakar/Documents/Preventive Maintenance/1. Dataset'

# List of the four training file names
file_names_training = ['train_FD001.txt', 'train_FD002.txt', 'train_FD003.txt', 'train_FD004.txt']

# List of the four testing file names
file_names_testing = ['test_FD001.txt', 'test_FD002.txt', 'test_FD003.txt', 'test_FD004.txt']

# List of the four RUL file names
file_names_rul = ['RUL_FD001.txt', 'RUL_FD002.txt', 'RUL_FD003.txt', 'RUL_FD004.txt']

# Dictionary to store the DataFrames
train_datasets = {}
test_datasets = {}
rul_datasets = {}

# Function to create sequences
def create_sequences(data, seq_length):
    sequences = []
    for i in range(len(data) - seq_length + 1):
        sequences.append(data[i:i+seq_length])
    return np.array(sequences)

sequence_length = 50  # Example sequence length

# Loop through each file and load it
for file in file_names_training:
    # Extract the dataset name (e.g., FD001)
    dataset_name = file.split('.')[0]  # Removes '.txt'
    
    # Read the file
    df = pd.read_csv(os.path.join(base_directory, file), sep='\s+', header=None, names=column_names)

    # Add a column to identify which dataset it came from (optional, for comparison)
    df['dataset'] = dataset_name

    # --- Step 1: Select Sensor Columns ---
    sensor_columns = [col for col in column_names if col not in ['unit_number', 'time_in_cycles', 'setting_1', 'setting_2', 'setting_3']]
    data_to_normalize = df[sensor_columns]
    
     # --- Step 2: Normalize the Data ---
    scaler = StandardScaler()
    
    # Identify the healthy phase (e.g., first 60% of each engine's life)
    df['cycle_norm'] = df.groupby('unit_number')['time_in_cycles'].transform(lambda x: x / x.max())
    healthy_mask = df['cycle_norm'] <= 0.6
    
    # Fit the scaler on healthy data only
    healthy_data = data_to_normalize[healthy_mask]
    scaler.fit(healthy_data)
    
    # Transform the entire dataset
    normalized_data = scaler.transform(data_to_normalize)
    
    #--Step 3: Create sequences--
    X_sequences = create_sequences(normalized_data, sequence_length)
    y_sequences = X_sequences
    
    #store the processed sequences and labels
    train_datasets[dataset_name] = {
        'X': X_sequences,
        'y': y_sequences,
        'normalized_data': normalized_data,
        'scaler': scaler,
        'df':df
    }
    
    print(f"Successfully processed {dataset_name}.")
    print(f"  Shape of sequences: {X_sequences.shape}")

for file in file_names_testing:
    dataset_name = file.split('.')[0]  # Removes '.txt'
    df = pd.read_csv(os.path.join(base_directory, file), sep='\s+', header=None, names=column_names)
    df['dataset'] = dataset_name
    
    sensor_columns = [col for col in column_names if col not in ['unit_number', 'time_in_cycles', 'setting_1', 'setting_2', 'setting_3']]
    data_to_normalize = df[sensor_columns]

    corresponding_train_dataset = dataset_name.replace('test', 'train')
    scaler = train_datasets[corresponding_train_dataset]['scaler']  # Use the scaler from the training dataset
    normalized_data = scaler.transform(data_to_normalize)

    # Create sequences
    X_sequences = create_sequences(normalized_data, sequence_length)

    # Store processed test data
    test_datasets[dataset_name] = {
        'X': X_sequences,
        'df': df,
        'normalized_data': normalized_data,
        'scaler': scaler
    }
    
    print(f"Successfully processed test dataset {dataset_name}. Sequence shape: {X_sequences.shape}")
    
for file in file_names_rul:
    dataset_name = file.split('.')[0]  # Removes '.txt'
    rul_df = pd.read_csv(os.path.join(base_directory, file), header=None, names=['RUL'])
    rul_datasets[dataset_name] = rul_df
    
    print(f"Successfully processed RUL dataset {dataset_name}. Shape: {rul_df.shape}")

def sampling(args):
    """
    Reparameterization trick to sample from the latent space.
    Instead of sampling directly from z_mean and z_log_var,
    we sample epsilon from N(0, I) and compute z = z_mean + exp(z_log_var / 2) * epsilon.
    This allows gradients to flow through the sampling operation.
    """
    z_mean, z_log_var = args
    batch = tf.shape(z_mean)[0]
    dim = tf.shape(z_mean)[1]
    # Reparameterization trick
    epsilon = K.random_normal(shape=(batch, dim))
    return z_mean + K.exp(0.5 * z_log_var) * epsilon

def build_VAE_lstm_autoencoder(input_shape, lstm_units_enc=[64, 32, 16], lstm_units_dec=[16, 32, 64], latent_dim=12, dropout_rate=0.2):
    sequence_length = input_shape[0]
    num_features = input_shape[1]
    inputs = Input(shape=input_shape)
    x = inputs
    for units in lstm_units_enc:
        x = LSTM(units, activation='tanh', return_sequences=True)(x)
        x = Dropout(dropout_rate)(x)
    x_flat = tf.keras.layers.GlobalAveragePooling1D()(x)
    z_mean = Dense(latent_dim)(x_flat)
    z_log_var = Dense(latent_dim)(x_flat)
    z = Lambda(sampling, output_shape=(latent_dim,))([z_mean, z_log_var])
    encoder = Model(inputs, [z_mean, z_log_var, z], name="encoder")
    encoder.summary()

    # Decoder
    latent_inputs = Input(shape=(latent_dim,))
    x = RepeatVector(sequence_length)(latent_inputs)
    for units in lstm_units_dec:
        x = LSTM(units, activation='tanh', return_sequences=True)(x)
        x = Dropout(dropout_rate)(x)
    outputs = TimeDistributed(Dense(num_features))(x)
    decoder = Model(latent_inputs, outputs, name="decoder")
    decoder.summary()

    # VAE Model
    outputs = decoder(encoder(inputs)[2])
    vae = Model(inputs, outputs, name="vae")
    vae.compile(optimizer=Adam(learning_rate=0.001), loss='mse')
    return vae
    return model

chosen_train_dataset = 'train_FD004'  # Example dataset to train on
X_train = train_datasets[chosen_train_dataset]['X']
y_train = X_train
input_shape = (X_train.shape[1], X_train.shape[2])  # (sequence_length, number of features)

# Train the model
model = build_VAE_lstm_autoencoder(input_shape)
early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
history = model.fit(X_train, y_train, epochs=100, batch_size=32, validation_split=0.2, shuffle=False, callbacks=[early_stopping])

# Define last N cycles as anomalous - CORRECTED FUNCTION
def create_true_labels_for_sequences(df, sequence_length, anomaly_window):
    # if 'max_cycle' not in df.columns:
    #     raise ValueError("DataFrame must have 'max_cycle' column calculated.")
    if 'time_in_cycles' not in df.columns:
        raise ValueError("DataFrame must have 'time_in_cycles' column.")
    
    df = df.copy()
    df['max_cycle'] = df.groupby('unit_number')['time_in_cycles'].transform('max')
    df['cycles_to_failure'] = df['max_cycle'] - df['time_in_cycles']
    df['true_anomaly'] = (df['cycles_to_failure'] < anomaly_window).astype(int)
    
    true_labels = []
    cycles_to_failure = []
    for unit in sorted(df['unit_number'].unique()):
        unit_data = df[df['unit_number'] == unit]
        unit_labels = unit_data['true_anomaly'].values
        unit_c2f = unit_data['cycles_to_failure'].values
        unit_cycles = unit_data['time_in_cycles'].values
        
        if len(unit_data) >= sequence_length:
            # For each sequence, label is at the END of sequence
            for i in range(len(unit_data) - sequence_length + 1):
                end_idx = i + sequence_length - 1
                true_labels.append(unit_labels[end_idx])
                cycles_to_failure.append(unit_c2f[end_idx])
                
    return np.array(true_labels), np.array(cycles_to_failure)

#reconstruct the sequences
chosen_RUL_dataset = 'RUL_FD004'  # Example RUL dataset to use
anomaly_window = 30  # Define the window for anomalies
chosen_test_dataset = 'test_FD004'  # Example dataset to test on
# Calculate the threshold from the TRAINING data (healthy portion only)
train_df = train_datasets[chosen_train_dataset]['df'].copy()

# The healthy sequences are those that END in the healthy phase
sequence_end_indices = np.arange(sequence_length - 1, len(train_df))
healthy_mask_threshold = train_df['cycle_norm'] <= 0.7
healthy_sequence_mask = healthy_mask_threshold.iloc[sequence_end_indices].values

# Filter the training MSE to only include healthy sequences
train_reconstructions = model.predict(X_train)
train_mse = np.mean((X_train - train_reconstructions) ** 2, axis=(1, 2))
print("Min MSE:", train_mse.min())
print("Max MSE:", train_mse.max())
print("Mean MSE:", train_mse.mean())
healthy_train_mse = train_mse[healthy_sequence_mask]




# Create proper true labels - CORRECT WAY
true_labels, cycles_to_failure = create_true_labels_for_sequences(train_df, sequence_length, anomaly_window)

# Ensure alignment
if len(train_mse) != len(true_labels):
    min_len = min(len(train_mse), len(true_labels))
    train_mse = train_mse[:min_len]
    true_labels = true_labels[:min_len]
    cycles_to_failure = cycles_to_failure[:min_len]
    print(f"Aligned lengths to: {min_len}")

# Calculate the threshold from the healthy data
threshold = np.mean(healthy_train_mse) + 1.2 * np.std(healthy_train_mse)

# Classify test sequences as Normal (0) or Anomalous (1)
train_predictions = (train_mse > threshold).astype(int)

print(f"Anomaly detection threshold: {threshold:.4f}")
print(f"Number of anomalies detected in train set: {np.sum(train_predictions)}")

X_test = test_datasets[chosen_test_dataset]['X']
reconstruction = model.predict(X_test)
test_mse = np.mean(np.square(X_test - reconstruction), axis=(1, 2))

def generate_test_set_labels_and_c2f(test_datasets, rul_datasets, sequence_length, anomaly_window):
    test_df_full = test_datasets[chosen_test_dataset]['df']
    rul_df = rul_datasets[chosen_RUL_dataset]
    unique_units = sorted(test_df_full['unit_number'].unique())

    
    all_true_labels = []
    all_cycles_to_failure = []
    
    for unit in unique_units:
        unit_mask = test_df_full['unit_number'] == unit
        unit_data = test_df_full[unit_mask].copy()
        num_test_cycles = len(unit_data)
        unit_data['max_cycle'] = unit_data['time_in_cycles'].max()
        unit_data['cycles_to_failure'] = unit_data['max_cycle'] - unit_data['time_in_cycles']
        
        if num_test_cycles < sequence_length:
            print(f"Unit {unit} has insufficient data for sequences")
            continue
        
        # Get the RUL for this unit from the RUL dataframe
        rul_value = rul_df.iloc[unit - 1]['RUL']
        max_cycle = num_test_cycles + rul_value
        unit_data['max_cycle'] = max_cycle
        
        try:
            unit_true_labels, unit_c2f = create_true_labels_for_sequences(unit_data, sequence_length, anomaly_window)
            all_true_labels.extend(unit_true_labels)
            all_cycles_to_failure.extend(unit_c2f)
        except ValueError as e:
            print(f"Error processing unit {unit}: {e}")
    
    if all_true_labels and all_cycles_to_failure:
        test_true_labels = np.array(all_true_labels)
        test_cycles_to_failure = np.array(all_cycles_to_failure)
        return test_true_labels, test_cycles_to_failure
    else:
        return np.array([]), np.array([])
    
test_true_labels, test_cycles_to_failure_end = generate_test_set_labels_and_c2f(
    test_datasets, rul_datasets, sequence_length, anomaly_window
)


#calculate early detection rate
def calculate_early_detection_rate(true_labels, predictions, cycles_to_failure, horizon):
    anomaly_indices = np.where(true_labels == 1)[0]
    early_detections = 0
    for idx in anomaly_indices:
        if predictions[idx] == 1 and cycles_to_failure[idx] <= horizon:
            early_detections += 1
    total_actual_anomalies = len(anomaly_indices)
    return early_detections / total_actual_anomalies if total_actual_anomalies > 0 else 0

def calculate_false_positive_rate(true_labels, predictions):
    normal_indices = np.where(true_labels == 0)[0]
    false_alarms = 0
    for idx in normal_indices:
        if predictions[idx] == 1:
            false_alarms += 1
    total_normal = len(normal_indices)
    return false_alarms / total_normal if total_normal > 0 else 0


if len(test_mse) > 0 and len(test_true_labels) > 0:
    # Ensure alignment (should be okay if generated correctly)
    min_test_len = min(len(test_mse), len(test_true_labels), len(test_cycles_to_failure_end))
    test_mse_aligned = test_mse[:min_test_len]
    test_true_labels_aligned = test_true_labels[:min_test_len]
    test_cycles_to_failure_end_aligned = test_cycles_to_failure_end[:min_test_len]

    test_predictions = (test_mse_aligned > threshold).astype(int)

    # 4. Calculate Metrics on Test Set
    horizon = 20 # Define your horizon
    # Ensure calculate_early_detection_rate and calculate_false_positive_rate are corrected
    # e.g., calculate_early_detection_rate should calculate anomaly_indices internally
    # and use cycles_to_failure[idx] >= horizon for early detection logic

    edr_test = calculate_early_detection_rate(test_true_labels_aligned, test_predictions, test_cycles_to_failure_end_aligned, horizon)
    fpr_test = calculate_false_positive_rate(test_true_labels_aligned, test_predictions)

    print(f"\n--- Test Set Performance Metrics (Threshold: {threshold:.4f}) ---")
    print(f"Early Detection Rate ({horizon} cycles early): {edr_test:.4f}")
    print(f"False Positive Rate: {fpr_test:.4f}")
    print(f"Total Test Sequences: {len(test_true_labels_aligned)}")
    print(f"Actual Anomalies in Test Set: {np.sum(test_true_labels_aligned)}")
    print(f"Predicted Anomalies in Test Set: {np.sum(test_predictions)}")

else:
    print("Could not generate test set labels or predictions due to insufficient data or errors.")

# if 'cycles_to_failure' not in train_df.columns:
#     train_df['max_cycle'] = train_df.groupby('unit_number')['time_in_cycles'].transform('max')
#     train_df['cycles_to_failure'] = train_df['max_cycle'] - train_df['time_in_cycles']

horizon = 15  # Define how many cycles before failure we consider for early detection
edr_train = calculate_early_detection_rate(true_labels, train_predictions, cycles_to_failure, horizon)
fpr_train = calculate_false_positive_rate(true_labels, train_predictions)
print(f"Early Detection Rate (EDR) on training set: {edr_train:.4f}")
print(f"False Positive Rate (FPR) on training set: {fpr_train:.4f}")

# Comprehensive evaluation
print(f"\nClass Distribution:")
print(f"Normal samples: {np.sum(true_labels == 0)}")
print(f"Anomalous samples: {np.sum(true_labels == 1)}")
print(f"Anomaly ratio: {np.mean(true_labels):.4f}")

# accuracy = accuracy_score(true_labels, train_predictions)
# precision = precision_score(true_labels, train_predictions, zero_division=0)
# recall = recall_score(true_labels, train_predictions, zero_division=0)
# f1 = f1_score(true_labels, train_predictions, zero_division=0)

# print(f"\nDetailed Classification Report:")
# print(classification_report(true_labels, train_predictions))


percentiles = [90, 92, 95, 97, 99]
results = []

for p in percentiles:
    threshold = np.percentile(healthy_train_mse, p)
    train_predictions = (train_mse > threshold).astype(int)
    # prec = precision_score(true_labels, train_predictions, zero_division=0)
    # rec = recall_score(true_labels, train_predictions, zero_division=0)
    # f1 = f1_score(true_labels, train_predictions, zero_division=0)
    anomalies_detected = np.sum(train_predictions)
    results.append((p, threshold, anomalies_detected))
    print(f"Percentile: {p}, Threshold: {threshold:.4f}, ")
        #   f"Precision: {prec:.4f}, Recall: {rec:.4f}, F1-Score: {f1:.4f}")
    # print(classification_report(true_labels, train_predictions))


#find a specific engine
engine_id = 75
engine_mask = test_datasets[chosen_test_dataset]['df']['unit_number'] == engine_id
engine_df = test_datasets[chosen_test_dataset]['df'][engine_mask]
engine_cycles = engine_df['time_in_cycles'].values

# Calculate sequence start index more reliably
sequence_start_idx = 0
for i in range(1, engine_id):
    prev_engine_mask = test_datasets[chosen_test_dataset]['df']['unit_number'] == i
    prev_engine_cycles = test_datasets[chosen_test_dataset]['df'][prev_engine_mask]['time_in_cycles'].values
    if len(prev_engine_cycles) >= sequence_length:
        sequence_start_idx += len(prev_engine_cycles) - sequence_length + 1

num_sequences = len(engine_cycles) - sequence_length + 1
if num_sequences > 0:
    engine_mse = test_mse[sequence_start_idx:sequence_start_idx + num_sequences]
    x_axis_cycles = engine_cycles[sequence_length - 1:]
else:
    print(f"Engine {engine_id} has insufficient data for sequences")
    engine_mse = np.array([])
    x_axis_cycles = np.array([])

if len(engine_mse) > 0:
    plt.figure(figsize=(12, 6))
    plt.plot(x_axis_cycles, engine_mse, label='Reconstruction Error (MSE)')
    plt.axhline(y=threshold, color='r', linestyle='--', label='Anomaly Threshold')
    plt.xlabel('Time in Cycles')
    plt.ylabel('Reconstruction Error (MSE)')
    plt.title(f'Anomaly Detection for Engine {engine_id} (Test Dataset {chosen_test_dataset})')
    plt.legend()
    plt.grid(True)
    plt.show()

    # Anomaly prediction
    if len(engine_mse) >= 20:  # Need at least 20 points for prediction
        N = min(20, len(engine_mse))
        X = x_axis_cycles[-N:].reshape(-1, 1)
        y = engine_mse[-N:]

        # Polynomial feature expansion
        poly = PolynomialFeatures(degree=2)
        X_poly = poly.fit_transform(X)

        # Train a polynomial regression model
        poly_model = Ridge(alpha=1.0)
        poly_model.fit(X_poly, y)

        # Predict on historical data to visualize fit
        y_pred = poly_model.predict(X_poly)

        # Predict the next M cycles
        M = 50
        X_future = np.arange(x_axis_cycles[-1] + 1, x_axis_cycles[-1] + M + 1).reshape(-1, 1)
        X_future_poly = poly.transform(X_future)
        y_future = poly_model.predict(X_future_poly)

        plt.figure(figsize=(12, 6))
        plt.plot(x_axis_cycles, engine_mse, label='Reconstruction Error (MSE)')
        plt.plot(x_axis_cycles[-N:], y_pred, label='Model Fit (Last 20 Cycles)', color='green', linestyle='-', linewidth=2)
        plt.plot(X_future.flatten(), y_future, label='Predicted Future MSE', color='orange')
        plt.axhline(y=threshold, color='r', linestyle='--', label='Anomaly Threshold')
        
        # Find when the future MSE exceeds the threshold
        anomaly_indices = np.where(y_future > threshold)[0]
        if len(anomaly_indices) > 0:
            anomaly_cycle = X_future[anomaly_indices[0]][0]
            print(f"Anomaly predicted at cycle: {anomaly_cycle}")
            plt.axvline(x=anomaly_cycle, color='g', linestyle='--', label='Predicted Anomaly Cycle')
        else:
            print("No anomaly predicted in the next 50 cycles")
        plt.xlabel('Time in Cycles')
        plt.ylabel('Reconstruction Error (MSE)')
        plt.title(f'Anomaly Prediction for Engine {engine_id} (Test Dataset {chosen_test_dataset})')
        plt.legend()
        plt.grid(True)
        plt.show()

# Assuming 'history' is the object returned by model.fit()
# Plot training & validation loss values
plt.figure(figsize=(10, 6))
plt.plot(history.history['loss'], label='Training Loss (MSE)')
plt.plot(history.history['val_loss'], label='Validation Loss (MSE)')
plt.title('Model Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss (MSE)')
plt.legend()
plt.grid(True)
plt.show()
# #RUL prediction
# # Calculate the RUL for the test dataset
# failure_window = 50

# def create_rul_sequences(data, failure_window):
#     rul_sequences = []
#     for i in range(len(data) - failure_window + 1):
#         rul_sequences.append(data[i:i + failure_window])
#     return np.array(rul_sequences)

# rul_sequences = create_rul_sequences(engine_mse, failure_window)

# chosen_RUL_dataset = 'RUL_FD004'  # Example RUL dataset
# rul_df = rul_datasets[chosen_RUL_dataset]
# rul_values = rul_df['RUL'].values
# true_rul_value = rul_df.iloc[engine_id - 1]['RUL'] 

# rul_targets = np.full(len(rul_sequences), true_rul_value)
# # current_index = 0
# # for i in test_datasets[chosen_test_dataset]['df']['unit_number'].unique():
# #     engine_mask = test_datasets[chosen_test_dataset]['df']['unit_number'] == i
# #     num_engine_cycles = test_datasets[chosen_test_dataset]['df'][engine_mask]['time_in_cycles'].values
# #     num_engine_sequences = len(num_engine_cycles) - sequence_length + 1

# #     engine_true_rul = rul_values[i - 1]

# #     rul_targets.extend([engine_true_rul] * num_engine_sequences)
# #     current_index += num_engine_sequences

# # rul_targets = np.array(rul_targets)

# # valid_rul_sequences = rul_sequences[failure_window - 1:]
# # valid_rul_targets = rul_targets[failure_window - 1:]

# def build_rul_model(input_shape):
#     model = Sequential()
#     model.add(Input(shape=input_shape))
#     model.add(LSTM(50, activation='relu', return_sequences=True))
#     model.add(Dropout(0.3))
#     model.add(LSTM(25, activation='relu'))
#     model.add(Dropout(0.3))
#     model.add(Dense(1))
#     model.compile(optimizer='adam', loss='mse', metrics=['mae'])
#     return model

# rul_input_shape = (failure_window, 1)  # (sequence_length, number of features
# rul_model = build_rul_model(rul_input_shape)
# rul_model.summary()
# rul_model.fit(rul_sequences.reshape(-1, failure_window, 1), rul_targets, epochs=50, batch_size=32, validation_split=0.2, shuffle=False)

# rul_predictions = rul_model.predict(rul_sequences.reshape(-1, failure_window, 1))
# rul_mse = np.mean(np.square(rul_targets - rul_predictions), axis=1)
# rul_rmse = np.sqrt(rul_mse)

# plt.figure(figsize=(12, 6))
# plt.plot(rul_predictions, label='Predicted RUL', color='orange')
# plt.plot(rul_targets, label='True RUL', color='blue')
# plt.xlabel('Sequence Index')
# plt.ylabel('Remaining Useful Life (RUL)')
# plt.title(f'Remaining Useful Life Prediction for Engine {engine_id} (Test Dataset {chosen_test_dataset})')
# plt.legend()    
# plt.grid(True)
# plt.show()